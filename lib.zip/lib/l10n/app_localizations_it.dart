// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Italian (`it`).
class AppLocalizationsIt extends AppLocalizations {
  AppLocalizationsIt([String locale = 'it']) : super(locale);

  @override
  String get appName => 'Musly';

  @override
  String get emulatorDetected => 'Emulator Detected';

  @override
  String get emulatorNotAllowed =>
      'This app cannot run on an emulator.\\nPlease use a physical device.';

  @override
  String get goodMorning => 'Buon giorno';

  @override
  String get goodAfternoon => 'Buona sera';

  @override
  String get goodEvening => 'Buon pomeriggio';

  @override
  String get forYou => 'Per Te';

  @override
  String get quickPicks => 'Scelte Rapide';

  @override
  String get discoverMix => 'Mix Scoperta';

  @override
  String get recentlyPlayed => 'Riprodotte Recentemente';

  @override
  String get yourPlaylists => 'Le Tue Playlist';

  @override
  String get favoritePlaylists => 'Favorite Playlists';

  @override
  String get sectionAlbums => 'Albums';

  @override
  String get sectionEPs => 'EPs';

  @override
  String get sectionSingles => 'Singles';

  @override
  String get madeForYou => 'Fatte Per Te';

  @override
  String get topRated => 'Più Votata';

  @override
  String get noContentAvailable => 'Nessun contenuto disponibile';

  @override
  String get tryRefreshing =>
      'Prova ad aggiornare o controlla la connessione al server';

  @override
  String get refresh => 'Aggiorna';

  @override
  String get errorLoadingSongs => 'Errore durante il caricamento delle canzoni';

  @override
  String get noSongsInGenre => 'Nessun brano in questo genere';

  @override
  String get errorLoadingAlbums => 'Errore nel caricamento degli album';

  @override
  String get noTopRatedAlbums => 'Nessun album classificato';

  @override
  String get login => 'Accedi';

  @override
  String get serverUrl => 'URL del Server';

  @override
  String get username => 'Nome Utente';

  @override
  String get password => 'Password';

  @override
  String get selectCertificate => 'Seleziona Certificato TLS/SSL';

  @override
  String failedToSelectCertificate(String error) {
    return 'Impossibile selezionare il certificato: $error';
  }

  @override
  String get serverUrlMustStartWith =>
      'L\'URL del server deve iniziare con http:// o https://';

  @override
  String get failedToConnect => 'Connessione fallita';

  @override
  String get library => 'Libreria';

  @override
  String get search => 'Cerca';

  @override
  String get settings => 'Impostazioni';

  @override
  String get albums => 'Album';

  @override
  String get artists => 'Artisti';

  @override
  String get songs => 'Brani';

  @override
  String get playlists => 'Playlist';

  @override
  String get genres => 'Generi';

  @override
  String get years => 'Years';

  @override
  String get favorites => 'Preferiti';

  @override
  String get nowPlaying => 'In riproduzione';

  @override
  String get queue => 'Coda';

  @override
  String get lyrics => 'Testi';

  @override
  String get play => 'Riproduci';

  @override
  String get pause => 'Pausa';

  @override
  String get next => 'Successivo';

  @override
  String get previous => 'Precedente';

  @override
  String get shuffle => 'Casuale';

  @override
  String get repeat => 'Ripeti';

  @override
  String get repeatOne => 'Ripeti una volta';

  @override
  String get repeatOff => 'Ripetizione disattivata';

  @override
  String get addToPlaylist => 'Aggiungi alla Playlist';

  @override
  String get removeFromPlaylist => 'Rimuovi dalla Playlist';

  @override
  String get addToFavorites => 'Aggiungi ai Preferiti';

  @override
  String get removeFromFavorites => 'Rimuovi dai Preferiti';

  @override
  String get download => 'Scarica';

  @override
  String get delete => 'Cancella';

  @override
  String get cancel => 'Annulla';

  @override
  String get ok => 'OK';

  @override
  String get save => 'Salva';

  @override
  String get close => 'Chiudi';

  @override
  String get general => 'Generale';

  @override
  String get appearance => 'Aspetto';

  @override
  String get playback => 'Riproduzione';

  @override
  String get storage => 'Spazio di archiviazione';

  @override
  String get about => 'Informazioni';

  @override
  String get darkMode => 'Tema Scuro';

  @override
  String get language => 'Lingua';

  @override
  String get version => 'Versione';

  @override
  String get madeBy => 'Realizzato da dddevid';

  @override
  String get githubRepository => 'Repository GitHub';

  @override
  String get reportIssue => 'Segnala un problema';

  @override
  String get joinDiscord => 'Unisciti Alla Community Di Discord';

  @override
  String get unknownArtist => 'Artista sconosciuto';

  @override
  String get unknownAlbum => 'Album sconosciuto';

  @override
  String get playAll => 'Riproduci tutto';

  @override
  String get shuffleAll => 'Riproduzione casuale per tutti i brani';

  @override
  String get sortBy => 'Ordina Per';

  @override
  String get sortByName => 'Nome';

  @override
  String get sortByArtist => 'Artista';

  @override
  String get sortByAlbum => 'Album';

  @override
  String get sortByDate => 'Data';

  @override
  String get sortByDuration => 'Durata';

  @override
  String get ascending => 'Ascendente';

  @override
  String get descending => 'Discendente';

  @override
  String get noLyricsAvailable => 'Nessun testo disponibile per questo brano';

  @override
  String get loading => 'Caricamento in corso...';

  @override
  String get error => 'Errore';

  @override
  String get retry => 'Riprova';

  @override
  String get noResults => 'Nessun risultato';

  @override
  String get searchHint => 'Cerca brani, album, artisti...';

  @override
  String get allSongs => 'Tutti i Brani';

  @override
  String get allAlbums => 'Tutti Gli Album';

  @override
  String get allArtists => 'Tutti Gli Artisti';

  @override
  String trackNumber(int number) {
    return 'Traccia $number';
  }

  @override
  String songsCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count canzoni',
      one: '1 canzone',
      zero: 'Nessuna canzone',
    );
    return '$_temp0';
  }

  @override
  String albumsCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count album',
      one: '1 album',
      zero: 'Nessun album',
    );
    return '$_temp0';
  }

  @override
  String get logout => 'Logout';

  @override
  String get confirmLogout => 'Sei sicuro di volerti disconnettere?';

  @override
  String get yes => 'Si';

  @override
  String get no => 'No';

  @override
  String get offlineMode => 'Modalità offline';

  @override
  String get radio => 'Radio';

  @override
  String get changelog => 'Registro delle modifiche';

  @override
  String get platform => 'Piattaforma';

  @override
  String get server => 'Server';

  @override
  String get display => 'Schermo';

  @override
  String get playerInterface => 'Interfaccia Lettore';

  @override
  String get smartRecommendations => 'Raccomandazioni intelligenti';

  @override
  String get showVolumeSlider => 'Mostra Cursore Del Volume';

  @override
  String get showVolumeSliderSubtitle =>
      'Visualizza il controllo del volume nella schermata Ora in riproduzione';

  @override
  String get showStarRatings => 'Mostra Valutazioni Stella';

  @override
  String get showStarRatingsSubtitle => 'Vota brani e visualizza valutazioni';

  @override
  String get showMiniPlayerHeart => 'Show Heart Button';

  @override
  String get showMiniPlayerHeartSubtitle => 'Add to favorites from mini player';

  @override
  String get showMiniPlayerRepeat => 'Show Repeat Button';

  @override
  String get showMiniPlayerRepeatSubtitle =>
      'Toggle repeat mode from mini player';

  @override
  String get showMiniPlayerShuffle => 'Show Shuffle Button';

  @override
  String get showMiniPlayerShuffleSubtitle => 'Toggle shuffle from mini player';

  @override
  String get enableRecommendations => 'Attiva Raccomandazioni';

  @override
  String get enableRecommendationsSubtitle =>
      'Ottieni suggerimenti musicali personalizzati';

  @override
  String get listeningData => 'Dati Di Ascolto';

  @override
  String totalPlays(int count) {
    return '$count Riproduzioni Totali';
  }

  @override
  String get clearListeningHistory => 'Cancella Cronologia Ascolti';

  @override
  String get confirmClearHistory =>
      'Questo resetterà tutti i tuoi dati di ascolto e i tuoi consigli. Sei sicuro?';

  @override
  String get historyCleared => 'Cronologia di ascolto cancellata';

  @override
  String get discordStatus => 'Stato Discord';

  @override
  String get discordStatusSubtitle =>
      'Mostra il brano in riproduzione sul profilo Discord';

  @override
  String get selectLanguage => 'Seleziona lingua';

  @override
  String get systemDefault => 'Predefinita di Sistema';

  @override
  String get communityTranslations => 'Traduzioni da Community';

  @override
  String get communityTranslationsSubtitle =>
      'Aiuta a tradurre Musly su Crowdin';

  @override
  String get checkTranslationUpdates => 'Controlla aggiornamenti traduzioni';

  @override
  String get checkTranslationUpdatesSubtitle =>
      'Sincronizza le ultime traduzioni della community in tempo reale (OTA)';

  @override
  String get checkingTranslationUpdates =>
      'Controllo aggiornamenti traduzioni in corso…';

  @override
  String get translationsUpdated => 'Traduzioni aggiornate con successo!';

  @override
  String get translationsUpToDate => 'Le traduzioni sono già aggiornate';

  @override
  String get yourLibrary => 'La Tua Libreria';

  @override
  String get filterAll => 'Tutto';

  @override
  String get faves => 'Faves';

  @override
  String get filterPlaylists => 'Playlist';

  @override
  String get filterAlbums => 'Album';

  @override
  String get filterArtists => 'Artisti';

  @override
  String get likedSongs => 'Brani preferiti';

  @override
  String get likedAlbums => 'Liked Albums';

  @override
  String get noLikedAlbums => 'No liked albums yet';

  @override
  String get localMusicLibrary => 'Local Music Library';

  @override
  String get mergeLocalLibrary => 'Merge with Server Library';

  @override
  String get mergeLocalLibrarySubtitle =>
      'Show local music alongside your server library';

  @override
  String get localMusicStats => 'Local Music Files';

  @override
  String get addMusicFolder => 'Add Music Folder';

  @override
  String get rescanLocalMusic => 'Rescan Local Music';

  @override
  String get localLibraryEmpty => 'Your library is empty';

  @override
  String get localLibraryEmptySubtitle =>
      'No local music files were found. Tap the button below to scan again.';

  @override
  String get libraryEmpty => 'Your library is empty';

  @override
  String get libraryEmptySubtitle => 'Add some songs to get started.';

  @override
  String get scanForMusic => 'Scan for Music';

  @override
  String get radioStations => 'Stazioni radio';

  @override
  String get playlist => 'Playlist';

  @override
  String get internetRadio => 'Radio Internet';

  @override
  String get newPlaylist => 'Nuova Playlist';

  @override
  String get playlistName => 'Nome Playlist';

  @override
  String get create => 'Crea';

  @override
  String get deletePlaylist => 'Elimina Playlist';

  @override
  String deletePlaylistConfirmation(String name) {
    return 'Sei sicuro di voler eliminare la playlist \"$name\"?';
  }

  @override
  String playlistDeleted(String name) {
    return 'Playlist \"$name\" eliminata';
  }

  @override
  String errorCreatingPlaylist(Object error) {
    return 'Errore nella creazione della playlist: $error';
  }

  @override
  String errorDeletingPlaylist(Object error) {
    return 'Errore nell\'eliminare la playlist: $error';
  }

  @override
  String playlistCreated(String name) {
    return 'Playlist \"$name\" creata';
  }

  @override
  String get searchTitle => 'Cerca';

  @override
  String get searchPlaceholder => 'Artisti, Canzoni, Album';

  @override
  String get tryDifferentSearch => 'Prova un’altra ricerca';

  @override
  String get noSuggestions => 'Nessun suggerimento';

  @override
  String get browseCategories => 'Esplora le categorie';

  @override
  String get liveSearchSection => 'Ricerca';

  @override
  String get liveSearch => 'Ricerca Live';

  @override
  String get liveSearchSubtitle =>
      'Aggiorna i risultati mentre digiti invece di mostrare un menu a tendina';

  @override
  String get categoryMadeForYou => 'Fatte Per Te';

  @override
  String get categoryNewReleases => 'Nuovi Rilasci';

  @override
  String get categoryTopRated => 'I più votati';

  @override
  String get categoryGenres => 'Generi';

  @override
  String get categoryFavorites => 'Preferiti';

  @override
  String get categoryRadio => 'Radio';

  @override
  String get settingsTitle => 'Impostazioni';

  @override
  String get tabPlayback => 'Riproduzione';

  @override
  String get tabStorage => 'Spazio di archiviazione';

  @override
  String get tabServer => 'Server';

  @override
  String get tabDisplay => 'Schermo';

  @override
  String get tabSupport => 'Supporto';

  @override
  String get tabAbout => 'Informazioni';

  @override
  String get sectionAutoDj => 'AUTO DJ';

  @override
  String get autoDjMode => 'Modalità DJ Automatica';

  @override
  String songsToAdd(int count) {
    return 'Brani da aggiungere: $count';
  }

  @override
  String get sectionReplayGain => 'NORMALIZZAZIONE VOLUME (REPLAYGAIN)';

  @override
  String get replayGainMode => 'Modalità';

  @override
  String preamp(String value) {
    return 'Preamp: $value dB';
  }

  @override
  String get preventClipping => 'Previeni Il Clipping';

  @override
  String fallbackGain(String value) {
    return 'Guadagno Fallback: $value dB';
  }

  @override
  String get sectionStreamingQuality => 'QUALITÀ DI STREAMING';

  @override
  String get enableTranscoding => 'Abilita La Transcodifica';

  @override
  String get qualityWifi => 'Qualità WiFi';

  @override
  String get qualityMobile => 'Qualità Mobile';

  @override
  String get format => 'Formato';

  @override
  String get transcodingSubtitle =>
      'Riduce l\'utilizzo dei dati con qualità inferiore';

  @override
  String get modeOff => 'Off';

  @override
  String get modeTrack => 'Traccia';

  @override
  String get modeAlbum => 'Album';

  @override
  String get sectionServerConnection => 'CONNESSIONE DEL SERVER';

  @override
  String get serverType => 'Tipo di server';

  @override
  String get notConnected => 'Non connesso';

  @override
  String get unknown => 'Sconosciuto';

  @override
  String get sectionMusicFolders => 'CARTELLE MUSICA';

  @override
  String get musicFolders => 'Cartelle Musica';

  @override
  String get noMusicFolders => 'Nessuna cartella musicale trovata';

  @override
  String get sectionSavedProfiles => 'PROFILI SALVATI';

  @override
  String get switchProfile => 'Cambia Profilo';

  @override
  String get switchServer => 'Cambia Server';

  @override
  String get addProfile => 'Aggiungi Profilo';

  @override
  String switchProfileConfirmation(String profile) {
    return 'Connetti a \"$profile\"?';
  }

  @override
  String get sectionAccount => 'ACCOUNT';

  @override
  String get logoutConfirmation =>
      'Sei sicuro di voler uscire? Questo cancellerà tutti i dati memorizzati nella cache.';

  @override
  String get sectionCacheSettings => 'IMPOSTAZIONI CACHE';

  @override
  String get imageCache => 'Cache delle immagini';

  @override
  String get musicCache => 'Cache Della Musica';

  @override
  String get bpmCache => 'Cache BPM';

  @override
  String get saveAlbumCovers => 'Salva localmente le copertine degli album';

  @override
  String get saveSongMetadata => 'Salva i metadati del brano localmente';

  @override
  String get saveBpmAnalysis => 'Salva analisi BPM localmente';

  @override
  String get sectionCacheCleanup => 'PULIZIA DELLA CACHE';

  @override
  String get clearAllCache => 'Svuota tutta la cache';

  @override
  String get allCacheCleared => 'Tutta la cache cancellata';

  @override
  String get sectionOfflineDownloads => 'DOWNLOAD OFFLINE';

  @override
  String get downloadedSongs => 'Brani Scaricati';

  @override
  String downloadingLibrary(int progress, int total) {
    return 'Scaricamento Della Libreria... $progress/$total';
  }

  @override
  String get downloadAllLibrary => 'Scarica Tutta La Libreria';

  @override
  String downloadLibraryConfirm(int count) {
    return 'Questo scaricherà  $count brani sul tuo dispositivo. Questo potrebbe richiedere un po\' di tempo e utilizzare uno spazio di archiviazione significativo.\n\nContinuare?';
  }

  @override
  String get keepScreenOnDuringDownload => 'Keep Screen On';

  @override
  String get keepScreenOnDuringDownloadSubtitle =>
      'Prevents download from failing when device locks';

  @override
  String get parallelDownloads => 'Parallel Downloads';

  @override
  String get parallelDownloadsSubtitle =>
      'Download multiple songs simultaneously';

  @override
  String get downloadSingular => 'download';

  @override
  String get downloadPlural => 'downloads';

  @override
  String get slowerButStable => 'Slower but more stable';

  @override
  String get fasterButMoreData => 'Faster but uses more data';

  @override
  String get libraryDownloadStarted => 'Download della libreria avviato';

  @override
  String get deleteDownloads => 'Elimina tutti i download';

  @override
  String get downloadsDeleted => 'Tutti i download eliminati';

  @override
  String get noSongsAvailable =>
      'Nessun brano disponibile. Carica prima la tua libreria.';

  @override
  String get sectionBpmAnalysis => 'ANALISI BPM';

  @override
  String get cachedBpms => 'Cached BPMs';

  @override
  String get cacheAllBpms => 'Cache Tutti I Bpm';

  @override
  String get clearBpmCache => 'Cancella Cache BPM';

  @override
  String get bpmCacheCleared => 'Cache BPM cancellata';

  @override
  String downloadedStats(int count, String size) {
    return '$count canzoni • $size';
  }

  @override
  String get sectionInformation => 'INFORMAZIONI';

  @override
  String get sectionDeveloper => 'SVILUPPATORE';

  @override
  String get sectionLinks => 'LINKS';

  @override
  String get githubRepo => 'Repository GitHub';

  @override
  String get playingFrom => 'IN RIPRODUZIONE DA';

  @override
  String get live => 'IN DIRETTA';

  @override
  String get streamingLive => 'Streaming In Diretta';

  @override
  String get stopRadio => 'Ferma La Radio';

  @override
  String get removeFromLiked => 'Rimuovi dai brani aggiunti ai preferiti';

  @override
  String get addToLiked => 'Aggiungi alle canzoni preferite';

  @override
  String get playNext => 'Riproduci Successivo';

  @override
  String get addToQueue => 'Aggiungi alla coda';

  @override
  String get goToAlbum => 'Vai all\'album';

  @override
  String get goToArtist => 'Vai all\'artista';

  @override
  String get rateSong => 'Vota Brano';

  @override
  String rateSongValue(int rating, String stars) {
    return 'Valuta Canzone ($rating $stars)';
  }

  @override
  String get ratingRemoved => 'Valutazione rimossa';

  @override
  String rated(int rating, String stars) {
    return 'Votato $rating $stars';
  }

  @override
  String get removeRating => 'Rimuovi Voto';

  @override
  String get downloaded => 'Scaricato';

  @override
  String downloading(int percent) {
    return 'Scaricamento... $percent%';
  }

  @override
  String get removeDownload => 'Rimuovi download';

  @override
  String get removeDownloadConfirm =>
      'Rimuovere questa canzone dalla memoria offline?';

  @override
  String get downloadRemoved => 'Download rimosso';

  @override
  String downloadedTitle(String title) {
    return 'Scaricato \"$title\"';
  }

  @override
  String get downloadFailed => 'Download fallito';

  @override
  String downloadError(Object error) {
    return 'Errore di download: $error';
  }

  @override
  String addedToPlaylist(String title, String playlist) {
    return 'Aggiunto \"$title\" alla $playlist';
  }

  @override
  String errorAddingToPlaylist(Object error) {
    return 'Errore nell\'aggiungere alla playlist: $error';
  }

  @override
  String get noPlaylists => 'Nessuna playlist disponibile';

  @override
  String get createNewPlaylist => 'Crea Nuova Playlist';

  @override
  String artistNotFound(String name) {
    return 'Artista \"$name\" non trovato';
  }

  @override
  String errorSearchingArtist(Object error) {
    return 'Errore cercando l\'artista: $error';
  }

  @override
  String get selectArtist => 'Seleziona artista';

  @override
  String get removedFromFavorites => 'Rimosso dai preferiti';

  @override
  String get addedToFavorites => 'Aggiunto ai preferiti';

  @override
  String get star => 'stella';

  @override
  String get stars => 'stelle';

  @override
  String get albumNotFound => 'Album non trovato';

  @override
  String durationHoursMinutes(int hours, int minutes) {
    return '$hours HR $minutes MIN';
  }

  @override
  String durationMinutes(int minutes) {
    return '$minutes MIN';
  }

  @override
  String get topSongs => 'Canzoni più ascoltate';

  @override
  String get connected => 'Collegato';

  @override
  String get noSongPlaying => 'Nessuna brano in riproduzione';

  @override
  String get internetRadioUppercase => 'RADIO INTERNET';

  @override
  String get playingNext => 'Riproduzione Successiva';

  @override
  String get createPlaylistTitle => 'Crea playlist';

  @override
  String get playlistNameHint => 'Nome della playlist';

  @override
  String playlistCreatedWithSong(String name) {
    return 'Playlist creata \"$name\" con questa canzone';
  }

  @override
  String errorLoadingPlaylists(Object error) {
    return 'Errore nel caricare le playlist: $error';
  }

  @override
  String get playlistNotFound => 'Playlist non trovata';

  @override
  String get noSongsInPlaylist => 'Nessun brano in questa playlist';

  @override
  String get noFavoriteSongsYet => 'Ancora nessuna canzone preferita';

  @override
  String get noFavoriteAlbumsYet => 'Ancora nessun album preferito';

  @override
  String get listeningHistory => 'Cronologia Ascolti';

  @override
  String get noListeningHistory => 'Nessuna Cronologia Di Ascolto';

  @override
  String get songsWillAppearHere => 'Le canzoni che riproduci appariranno qui';

  @override
  String get sortByTitleAZ => 'Titolo (A-Z)';

  @override
  String get sortByTitleZA => 'Titolo (Z-A)';

  @override
  String get sortByArtistAZ => 'Artista (A-Z)';

  @override
  String get sortByArtistZA => 'Artista (Z-A)';

  @override
  String get sortByAlbumAZ => 'Album (A-Z)';

  @override
  String get sortByAlbumZA => 'Album (Z-A)';

  @override
  String get recentlyAdded => 'Aggiunto di Recente';

  @override
  String get noSongsFound => 'Nessuna canzone trovata';

  @override
  String get noAlbumsFound => 'Nessun album trovato';

  @override
  String get noHomepageUrl => 'Nessun URL di homepage disponibile';

  @override
  String get playStation => 'Play Station';

  @override
  String get openHomepage => 'Apri Homepage';

  @override
  String get copyStreamUrl => 'Copia URL streaming';

  @override
  String get failedToLoadRadioStations =>
      'Impossibile caricare le stazioni radio';

  @override
  String get noRadioStations => 'Nessuna stazione radio';

  @override
  String get noRadioStationsHint =>
      'Aggiungi stazioni radio nelle impostazioni del tuo server Navidrome per vederle qui.';

  @override
  String get connectToServerSubtitle => 'Connettiti al tuo server Subsonic';

  @override
  String get pleaseEnterServerUrl => 'Inserisci l\'URL del server';

  @override
  String get invalidUrlFormat => 'L\'URL deve iniziare con http:// o https://';

  @override
  String get pleaseEnterUsername => 'Inserisci il nome utente';

  @override
  String get pleaseEnterPassword => 'Inserisci la password';

  @override
  String get legacyAuthentication => 'Autenticazione Legacy';

  @override
  String get legacyAuthSubtitle => 'Usa per vecchi server Subsonic';

  @override
  String get allowSelfSignedCerts => 'Consenti Certificati Auto-Firmati';

  @override
  String get allowSelfSignedSubtitle =>
      'Per server con certificati TLS/SSL personalizzati';

  @override
  String get advancedOptions => 'Opzioni Avanzate';

  @override
  String get customTlsCertificate => 'Certificato TLS/Ssl Personalizzato';

  @override
  String get customCertificateSubtitle =>
      'Carica un certificato personalizzato per server con CA non standard';

  @override
  String get selectCertificateFile => 'Seleziona il file del certificato';

  @override
  String get clientCertificate => 'Certificato Client (mTLS)';

  @override
  String get clientCertificateSubtitle =>
      'Autenticare questo client utilizzando un certificato (richiede un server abilitato per mTLS)';

  @override
  String get selectClientCertificate => 'Seleziona Certificato Client';

  @override
  String get clientCertPassword => 'Password del certificato (opzionale)';

  @override
  String failedToSelectClientCert(String error) {
    return 'Impossibile selezionare il certificato: $error';
  }

  @override
  String get connect => 'Connetti';

  @override
  String get or => 'O';

  @override
  String get useLocalFiles => 'Usa File Locali';

  @override
  String get startingScan => 'Avvio scansione...';

  @override
  String get storagePermissionRequired => 'Permesso di archiviazione richiesto';

  @override
  String get noMusicFilesFound =>
      'Nessun file musicale trovato sul tuo dispositivo';

  @override
  String get remove => 'Rimuovi';

  @override
  String failedToSetRating(Object error) {
    return 'Impossibile impostare la valutazione: $error';
  }

  @override
  String get home => 'Home';

  @override
  String get playlistsSection => 'PLAYLISTS';

  @override
  String get collapse => 'Comprimi';

  @override
  String get expand => 'Espandi';

  @override
  String get createPlaylist => 'Crea playlist';

  @override
  String get likedSongsSidebar => 'Brani piaciuti';

  @override
  String playlistSongsCount(int count) {
    return '';
  }

  @override
  String get failedToLoadLyrics => 'Impossibile caricare i testi';

  @override
  String get lyricsNotFoundSubtitle =>
      'Impossibile trovare il testo di questa canzone';

  @override
  String get backToCurrent => 'Torna al corrente';

  @override
  String get exitFullscreen => 'Esci da schermo intero';

  @override
  String get fullscreen => 'Schermo Intero';

  @override
  String get noLyrics => 'Nessun testo';

  @override
  String get internetRadioMiniPlayer => 'Radio Internet';

  @override
  String get liveBadge => 'IN DIRETTA';

  @override
  String get localFilesModeBanner => 'Modalità File Locali';

  @override
  String get offlineModeBanner =>
      'Modalità offline – Solo riproduzione di musica scaricata';

  @override
  String get updateAvailable => 'Aggiornamento disponibile';

  @override
  String get updateAvailableSubtitle =>
      'Una nuova versione di Musly è disponibile!';

  @override
  String updateCurrentVersion(String version) {
    return 'Attuale: v$version';
  }

  @override
  String updateLatestVersion(String version) {
    return 'Ultima: v$version';
  }

  @override
  String get whatsNew => 'Cosa c\'è di nuovo';

  @override
  String get downloadUpdate => 'Scarica';

  @override
  String get remindLater => 'Dopo';

  @override
  String get seeAll => 'Vedi tutti';

  @override
  String get artistDataNotFound => 'Artista non trovato';

  @override
  String get addedArtistToQueue => 'Added artist to Queue';

  @override
  String get addedArtistToQueueError => 'Failed adding artist to Queue';

  @override
  String get casting => 'In trasmissione';

  @override
  String get dlna => 'DLNA';

  @override
  String get castDlnaBeta => 'Cast / DLNA (Beta)';

  @override
  String get chromecast => 'Chromecast';

  @override
  String get dlnaUpnp => 'DLNA / UPnP';

  @override
  String get disconnect => 'Disconnetti';

  @override
  String get searchingDevices => 'Ricerca di dispositivi in corso';

  @override
  String get castWifiHint =>
      'Assicurati che il tuo dispositivo Cast / DLNA\nsia sulla stessa rete Wi-Fi';

  @override
  String connectedToDevice(String name) {
    return 'Connesso a $name';
  }

  @override
  String failedToConnectDevice(String name) {
    return 'Impossibile connettersi a $name';
  }

  @override
  String get removedFromLikedSongs => 'Rimosso da brani che ti piacciono';

  @override
  String get addedToLikedSongs => 'Aggiunto a brani che ti piacciono';

  @override
  String get enableShuffle => 'Attiva la riproduzione casuale';

  @override
  String get enableRepeat => 'Abilita ripetizione';

  @override
  String get connecting => 'In connessione';

  @override
  String get closeLyrics => 'Chiudi Testi';

  @override
  String errorStartingDownload(Object error) {
    return 'Errore nell\'avvio del download: $error';
  }

  @override
  String get errorLoadingGenres => 'Errore nel caricamento dei generi';

  @override
  String get noGenresFound => 'Nessun genere trovato';

  @override
  String get noAlbumsInGenre => 'Nessun album in questo genere';

  @override
  String genreTooltip(int songCount, int albumCount) {
    return '$songCount canzoni • $albumCount album';
  }

  @override
  String get sectionJukebox => 'MODALITÀ JUKEBOX';

  @override
  String get jukeboxMode => 'Modalità Jukebox';

  @override
  String get jukeboxModeSubtitle =>
      'Riproduci l\'audio tramite il server invece di questo dispositivo';

  @override
  String get openJukeboxController => 'Apri Controller Jukebox';

  @override
  String get jukeboxClearQueue => 'Cancella la coda';

  @override
  String get jukeboxShuffleQueue => 'Mescola la coda';

  @override
  String get jukeboxQueueEmpty => 'Nessuna canzone in coda';

  @override
  String get jukeboxNowPlaying => 'Riproduzione in corso';

  @override
  String get jukeboxQueue => 'Coda';

  @override
  String get jukeboxVolume => 'Volume';

  @override
  String get playOnJukebox => 'Riproduci su Jukebox';

  @override
  String get addToJukeboxQueue => 'Aggiungi alla coda di Jukebox';

  @override
  String get jukeboxNotSupported =>
      'La modalità Jukebox non è supportata da questo server. Abilitarla nella configurazione del server (ad es. EnableJukebox = true in Navidrome).';

  @override
  String get musicFoldersDialogTitle => 'Seleziona Cartelle Musicali';

  @override
  String get musicFoldersHint =>
      'Lascia tutto abilitato per usare tutte le cartelle (predefinito).';

  @override
  String get musicFoldersSaved => 'Selezione di cartelle musicali salvata';

  @override
  String get artworkStyleSection => 'Stile Grafica';

  @override
  String get artworkCornerRadius => 'Raggio Angoli';

  @override
  String get artworkCornerRadiusSubtitle =>
      'Regola come appaiono gli angoli delle copertine degli album';

  @override
  String get artworkCornerRadiusNone => 'Nessuno';

  @override
  String get artworkShape => 'Forma';

  @override
  String get artworkShapeRounded => 'Arrotondato';

  @override
  String get artworkShapeCircle => 'Cerchio';

  @override
  String get artworkShapeSquare => 'Quadrato';

  @override
  String get artworkShadow => 'Ombra';

  @override
  String get artworkShadowNone => 'Nessuno';

  @override
  String get artworkShadowSoft => 'Soft';

  @override
  String get artworkShadowMedium => 'Medio';

  @override
  String get artworkShadowStrong => 'Strong';

  @override
  String get artworkShadowColor => 'Colore ombreggiatura';

  @override
  String get artworkShadowColorBlack => 'Nero';

  @override
  String get artworkShadowColorAccent => 'Accento';

  @override
  String get artworkPreview => 'Anteprima';

  @override
  String artworkCornerRadiusLabel(int value) {
    return '${value}px';
  }

  @override
  String get noArtwork => 'Nessuna copertina';

  @override
  String get serverUnreachableTitle => 'Impossibile raggiungere il server';

  @override
  String get serverUnreachableSubtitle =>
      'Controllare la connessione o le impostazioni del server.';

  @override
  String get openOfflineMode => 'Apri in modalità offline';

  @override
  String get appearanceSection => 'Aspetto';

  @override
  String get themeLabel => 'Tema';

  @override
  String get accentColorLabel => 'Tema colore';

  @override
  String get circularDesignLabel => 'Design Circolare';

  @override
  String get circularDesignSubtitle =>
      'UI galleggiante e arrotondata con pannelli traslucidi ed effetto sfocatura di vetro sul lettore e sulla barra di navigazione.';

  @override
  String get themeModeSystem => 'Sistema';

  @override
  String get themeModeLight => 'Chiaro';

  @override
  String get themeModeDark => 'Scuro';

  @override
  String get liveLabel => 'LIVE';

  @override
  String get discordStatusText => 'Stato di Discord';

  @override
  String get discordStatusTextSubtitle =>
      'Seconda riga mostrata nell\'attività di Discord';

  @override
  String get discordRpcStyleArtist => 'Nome artista';

  @override
  String get discordRpcStyleSong => 'Titolo del brano';

  @override
  String get discordRpcStyleApp => 'Nome app (Musly)';

  @override
  String get sectionVolumeNormalization =>
      'NORMALIZZAZIONE VOLUME (REPLAYGAIN)';

  @override
  String get sectionFadeInOut => 'FADE IN/OUT';

  @override
  String get fadeInOutEnable => 'Enable Fade In/Out';

  @override
  String get fadeInOutSubtitle => 'Smoothly fade audio when playing or pausing';

  @override
  String fadeDuration(int duration) {
    return 'Fade Duration: ${duration}ms';
  }

  @override
  String get replayGainModeOff => 'Off';

  @override
  String get replayGainModeTrack => 'Traccia';

  @override
  String get replayGainModeAlbum => 'Album';

  @override
  String replayGainPreamp(String value) {
    return 'Preamp: $value dB';
  }

  @override
  String get replayGainPreventClipping => 'Previeni Il Clipping';

  @override
  String replayGainFallbackGain(String value) {
    return 'Guadagno Fallback: $value dB';
  }

  @override
  String autoDjSongsToAdd(int count) {
    return 'Brani da aggiungere: $count';
  }

  @override
  String get transcodingEnable => 'Abilita La Transcodifica';

  @override
  String get transcodingEnableSubtitle =>
      'Riduce l\'utilizzo dei dati con qualità inferiore';

  @override
  String get smartTranscoding => 'Trascodifica Intelligente';

  @override
  String get smartTranscodingSubtitle =>
      'Regola automaticamente la qualità in base alla tua connessione (WiFi vs dati mobili)';

  @override
  String get smartTranscodingDetectedNetwork => 'Rete rilevata: ';

  @override
  String smartTranscodingActiveBitrate(String bitrate) {
    return 'Bitrate attivo $bitrate';
  }

  @override
  String get transcodingWifiQuality => 'Qualità WiFi';

  @override
  String get transcodingWifiQualitySubtitleSmart =>
      'Usato automaticamente su WiFi';

  @override
  String get transcodingWifiQualitySubtitle => 'Bitrate quando su WiFi';

  @override
  String get transcodingMobileQuality => 'Qualità Mobile';

  @override
  String get transcodingMobileQualitySubtitleSmart =>
      'Utilizzato automaticamente su dati cellulari';

  @override
  String get transcodingMobileQualitySubtitle =>
      'Bitrate quando su dati mobili';

  @override
  String get transcodingFormat => 'Formato';

  @override
  String get transcodingFormatSubtitle =>
      'Codec audio utilizzato per lo streaming';

  @override
  String get transcodingBitrateOriginal => 'Originale (Nessuna Transcodifica)';

  @override
  String get transcodingFormatOriginal => 'Originale';

  @override
  String get imageCacheTitle => 'Cache immagini';

  @override
  String get imageCacheSubtitle => 'Salva localmente le copertine degli album';

  @override
  String get musicCacheTitle => 'Cache Della Musica';

  @override
  String get musicCacheSubtitle => 'Salva i metadati del brano localmente';

  @override
  String get bpmCacheTitle => 'Cache BPM';

  @override
  String get bpmCacheSubtitle => 'Salva analisi BPM localmente';

  @override
  String get sectionAboutInformation => 'INFORMAZIONI';

  @override
  String get sectionAboutDeveloper => 'SVILUPPATORE';

  @override
  String get sectionAboutLinks => 'LINKS';

  @override
  String get aboutVersion => 'Versione';

  @override
  String get aboutPlatform => 'Piattaforma';

  @override
  String get aboutMadeBy => 'Realizzato da dddevid';

  @override
  String get aboutGitHub => 'github.com/ddddevid';

  @override
  String get aboutLinkGitHub => 'Repository GitHub';

  @override
  String get aboutLinkChangelog => 'Changelog';

  @override
  String get aboutLinkReportIssue => 'Segnala un problema';

  @override
  String get aboutLinkDiscord => 'Unisciti Alla Community Di Discord';

  @override
  String get sectionAnalyticsPrivacy => 'Analytics & Privacy';

  @override
  String get anonymousAnalytics => 'Anonymous Analytics';

  @override
  String get anonymousAnalyticsSubtitle =>
      'Help improve Musly with anonymous crash reports and usage stats';

  @override
  String get deviceId => 'Device ID';

  @override
  String deviceIdAnonymous(String id) {
    return 'Anonymous ID: $id';
  }

  @override
  String get deviceIdDisabled =>
      'Enable analytics to see your anonymous device ID';

  @override
  String get aboutDeviceId => 'About Device ID';

  @override
  String get aboutDeviceIdSubtitle =>
      'This is an anonymous identifier generated by the app. It cannot be linked to your personal identity and is used only for analytics.';

  @override
  String get supportGreeting => 'Ciao!';

  @override
  String get supportParagraph1 =>
      'Sono Devid, lo sviluppatore di Musly. Ho creato questa app perché amo la musica e credo che tutti meritino un lettore musicale bellissimo e gratuito.';

  @override
  String get supportParagraph2 =>
      'Musly è completamente gratuito e open-source. Nessuna pubblicità, nessun abbonamento. Ci lavoro nel tempo libero perché mi piace davvero creare qualcosa di utile per persone come te.';

  @override
  String get supportParagraph3 =>
      'Ma server, strumenti di sviluppo e caffè non sono gratis Se Musly è diventato parte della tua giornata e vuoi dire \"grazie\", una piccola donazione significherebbe tantissimo per me. Aiuta a coprire i costi e mi motiva ad aggiungere nuove funzionalità.';

  @override
  String get supportParagraph4 =>
      'Ma nessuna pressione - il fatto che ti piaccia l\'app è già la migliore ricompensa!';

  @override
  String get supportDonationTitle => 'Supporta con una Donazione';

  @override
  String get supportDonationSubtitle => 'via Revolut - qualsiasi cifra aiuta!';

  @override
  String get supportDiscordTitle => 'Unisciti al nostro Discord';

  @override
  String get supportDiscordSubtitle =>
      'Ottieni aiuto, suggerisci funzionalità o chiacchiera';

  @override
  String get supportWaysTitle => 'Altri modi per supportare';

  @override
  String get supportWayRate => 'Lascia una recensione sull\'app store';

  @override
  String get supportWayShare => 'Parla di Musly ai tuoi amici';

  @override
  String get supportWayBugs => 'Segnala bug o suggerisci funzionalità';

  @override
  String get supportWayEnjoy => 'Semplicemente goditi la musica!';

  @override
  String get supportMadeWithLove => 'Crafted with passion in Italy';

  @override
  String get playbackSpeed => 'Playback Speed';

  @override
  String get normalSpeed => 'Normal (1×)';

  @override
  String get preservePitch => 'Preserve pitch';

  @override
  String get preservePitchSubtitle => 'Keep original pitch when changing speed';

  @override
  String get pitch => 'Pitch';

  @override
  String get pitchPreserved => 'pitch preserved';

  @override
  String speedTooltipWithPitch(String speed, String pitch) {
    return 'Speed $speed · pitch $pitch×';
  }

  @override
  String speedTooltipPitchPreserved(String speed) {
    return 'Speed $speed · pitch preserved';
  }

  @override
  String get sleepTimer => 'Sleep Timer';

  @override
  String get sleepTimerActive => 'Sleep timer active';

  @override
  String get fadeOut => 'Fade out';

  @override
  String fadeOutSubtitle(int seconds) {
    return 'Gradually lower volume in the last $seconds s';
  }

  @override
  String get finishCurrentSong => 'Finish current song';

  @override
  String get finishCurrentSongSubtitle => 'Stop after the current track ends';

  @override
  String sleepTimerMinutes(int count) {
    return '$count min';
  }

  @override
  String sleepTimerHours(int count) {
    return '$count hour';
  }

  @override
  String sleepTimerSetFor(String duration) {
    return 'Sleep timer set for $duration';
  }

  @override
  String get customDuration => 'Custom duration…';

  @override
  String get cancelTimer => 'Cancel timer';

  @override
  String get customSleepTimer => 'Custom Sleep Timer';

  @override
  String get set => 'Set';

  @override
  String get addToPlaylistTitle => 'Add to Playlist';

  @override
  String get yourPlaylistsLabel => 'Your Playlists';

  @override
  String get enableLrcLibFallback => 'Fetch lyrics from LRCLIB';

  @override
  String get lrcLibFallbackSubtitle =>
      'Automatically search LRCLIB for lyrics when your server does not provide them';

  @override
  String get themeSaved => 'Theme saved';

  @override
  String get themeUnsavedChanges => 'Unsaved changes';

  @override
  String get themeUnsavedChangesTitle => 'Unsaved Changes';

  @override
  String get themeUnsavedChangesBody =>
      'You have unsaved changes. Do you want to save before leaving?';

  @override
  String get discard => 'Discard';

  @override
  String get done => 'Done';

  @override
  String pickColor(String label) {
    return 'Pick $label';
  }

  @override
  String get titleStyle => 'Title Style';

  @override
  String get artistStyle => 'Artist Style';

  @override
  String get themeActive => 'ACTIVE';

  @override
  String get themeSafeMode => 'SAFE';

  @override
  String get themeCodeMode => 'CODE';

  @override
  String get themeAnimBadge => 'ANIM';

  @override
  String themeAuthor(String author) {
    return 'by $author';
  }

  @override
  String get audioFocusDenied =>
      'Couldn\'t start playback — another app has audio focus';

  @override
  String get addToLibrary => 'Add to Library';

  @override
  String get alreadyInLibrary => 'Song already in server library';

  @override
  String get selectPlaylist => 'Seleziona Playlist';

  @override
  String get endOfSong => 'Fine Brano';

  @override
  String get muslyConnect => 'Musly Connect';

  @override
  String get connectToDevice => 'Connetti a un Dispositivo';

  @override
  String get currentlyPlayingOn => 'In Riproduzione Su';

  @override
  String get noDevicesFound =>
      'Nessun altro dispositivo Musly trovato sulla tua rete Wi-Fi.';

  @override
  String get transferPlaybackHere => 'Trasferisci la riproduzione qui';

  @override
  String playbackTransferredTo(String device) {
    return 'Riproduzione trasferita su $device';
  }

  @override
  String get muslyBeatSync => 'Musly BeatSync';

  @override
  String get beatSyncSubtitle =>
      'Sincronizza più telefoni e computer su Wi-Fi come altoparlanti surround per le feste con precisione al millisecondo.';

  @override
  String get hostParty => 'Crea Party';

  @override
  String get joinParty => 'Unisciti al Party';

  @override
  String get leaveParty => 'Lascia il Party';

  @override
  String get audioPhaseCalibration => 'Calibrazione Fase Audio';

  @override
  String get phaseCalibrationSubtitle =>
      'Regola per compensare la latenza di cuffie o altoparlanti Bluetooth.';

  @override
  String get partySpeakers => 'Altoparlanti Party';

  @override
  String get muslyWrapped => 'Musly Wrapped';

  @override
  String get wrappedSeasonal => 'Musly Playback è Stagionale';

  @override
  String get playYourTopSongs => 'Riproduci i tuoi brani top';

  @override
  String get milestone50SongsTitle => 'Grazie di cuore!';

  @override
  String get milestone50SongsBadge => '50 BRANI ASCOLTATI';

  @override
  String get milestone50SongsMessage =>
      'Hai appena raggiunto il traguardo di 50 brani ascoltati su Musly! Grazie per aver scelto quest\'app per accompagnare la tua passione musicale ogni giorno.';

  @override
  String get continueListening => 'Continua ad ascoltare';

  @override
  String get lyricsUnderArtwork => 'Testo sotto la copertina';

  @override
  String get lyricsUnderArtworkSubtitle =>
      'Mostra la riga sincronizzata corrente del testo sotto la copertina nel player a schermo intero';

  @override
  String get lyricsDisplaySection => 'VISUALIZZAZIONE TESTO';

  @override
  String get lyricsBlurUnfocused => 'Sfoca testo non attivo';

  @override
  String get lyricsBlurUnfocusedSubtitle =>
      'Aggiunge un effetto di sfocatura alle righe del testo precedenti e successive';

  @override
  String get lyricsAlignment => 'Allineamento testo';

  @override
  String get lyricsAlignmentCentered => 'Centrato';

  @override
  String get lyricsAlignmentLeft => 'Allineato a sinistra';

  @override
  String get alignLeft => 'Sinistra';

  @override
  String get alignCenter => 'Centro';

  @override
  String get lyricsGlowEffect => 'Bagliore riga attiva';

  @override
  String get lyricsGlowEffectSubtitle =>
      'Effetto di bagliore sottile sulla riga del testo attualmente in riproduzione';

  @override
  String get hideWindowTitlebar =>
      'Nascondi barra del titolo / decorazioni della finestra';

  @override
  String get hideWindowTitlebarSubtitle =>
      'Nasconde la barra del titolo nativa (utile per Linux Wayland e tiling window manager)';

  @override
  String get sectionSmartCrossfade => 'SMART CROSSFADE';

  @override
  String get trackCrossfade => 'Dissolvenza incrociata tra i brani';

  @override
  String get crossfadeOffSubtitle => 'Disattivata (Transizione istantanea)';

  @override
  String crossfadeDurationSubtitle(int seconds) {
    return '$seconds secondi di dissolvenza incrociata tra i brani';
  }

  @override
  String crossfadeDurationBadge(int seconds) {
    return '${seconds}s';
  }

  @override
  String get sectionGaplessPlayback => 'RIPRODUZIONE SENZA PAUSE';

  @override
  String get gaplessPlayback => 'Riproduzione senza pause';

  @override
  String get gaplessPlaybackSubtitle => 'Elimina il silenzio tra i brani';

  @override
  String get sectionLyrics => 'TESTI';

  @override
  String get networkWifi => 'WiFi';

  @override
  String get networkMobile => 'Dati mobili';

  @override
  String get downloadFolder => 'Cartella di download';

  @override
  String get downloadFolderDefault => 'Predefinita (Memoria interna)';

  @override
  String get activeDownloads => 'Download attivi';

  @override
  String get noDownloadsInProgress => 'Nessun download in corso';

  @override
  String get playlistDownloads => 'Download playlist';

  @override
  String playlistSongsDownloadedCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count brani scaricati',
      one: '1 brano scaricato',
    );
    return '$_temp0';
  }

  @override
  String get songsStreamCache => 'Cache brani e streaming';

  @override
  String get imageArtworkCache => 'Cache copertine e immagini';

  @override
  String cacheDiskUsage(String size) {
    return '$size occupati su disco';
  }

  @override
  String totalCacheDiskUsage(String size) {
    return 'Totale cache: $size';
  }

  @override
  String get clearAudioCacheTooltip => 'Svuota cache brani';

  @override
  String get clearImageCacheTooltip => 'Svuota cache immagini';

  @override
  String get audioCacheCleared => 'Cache brani svuotata';

  @override
  String get imageCacheCleared => 'Cache copertine svuotata';

  @override
  String folderAdded(String path) {
    return 'Cartella aggiunta: $path';
  }

  @override
  String get removeFolderTitle => 'Rimuovi cartella';

  @override
  String removeFolderConfirm(String path) {
    return 'Rimuovere \"$path\" dai percorsi di scansione?';
  }

  @override
  String get folderRemoved => 'Cartella rimossa';

  @override
  String get loadingLibrary => 'Caricamento libreria in corso...';

  @override
  String get libraryEmptyError =>
      'La libreria sembra vuota o non è stato possibile caricarla. Assicurati che il tuo server supporti la scansione completa della libreria.';

  @override
  String get serverStatusConnected => 'CONNESSO';

  @override
  String get serverStatusConnecting => 'CONNESSIONE';

  @override
  String get serverStatusOffline => 'OFFLINE';

  @override
  String get serverStatusNotConnected => 'Non connesso';

  @override
  String get switchServerButton => 'Cambia';

  @override
  String get savedServersSection => 'SERVER E SERVIZI SALVATI';

  @override
  String get manage => 'Gestisci';

  @override
  String get serverActiveBadge => 'ATTIVO';

  @override
  String get addServerOrService => 'Aggiungi server o servizio';

  @override
  String get welcomeTourTitle => 'Tour di benvenuto';

  @override
  String get welcomeTourSubtitle =>
      'Rivedi l\'esperienza introduttiva iniziale';

  @override
  String get muslyPlaybackDev => 'Anteprima Playback (Modalità Test)';

  @override
  String get muslyPlaybackDevSubtitle =>
      'Esplora direttamente l\'anteprima del tuo Year-in-Review senza attendere novembre';

  @override
  String get muslyPlaybackAnnual => 'Musly Playback';

  @override
  String get muslyPlaybackAnnualSubtitle =>
      'Il tuo Year-in-Review annuale si sblocca automaticamente ogni anno tra fine novembre e metà gennaio.\n\nContinua ad ascoltare musica per espandere il tuo universo sonoro!';

  @override
  String get sectionAboutSupport => 'SUPPORTO';

  @override
  String get thanksForRating => 'Grazie per la valutazione!';

  @override
  String get rateMusly => 'Valuta Musly';

  @override
  String get alreadyRatedSubtitle => 'Hai già valutato l\'app';

  @override
  String get shareFeedbackSubtitle => 'Condividi la tua opinione';

  @override
  String get supportMuslyTitle => 'Supporta Musly';

  @override
  String get supportMuslySubtitle => 'Unisciti a Discord o fai una donazione';

  @override
  String get rateMuslyDialogTitle => 'Valuta Musly';

  @override
  String get rateMuslyDialogQuestion => 'Come valuteresti la tua esperienza?';

  @override
  String get optionalFeedbackHint => 'Feedback opzionale...';

  @override
  String get submit => 'Invia';

  @override
  String get thankYouFeedback => 'Grazie per il tuo feedback!';

  @override
  String devPlaybackTapsAway(int count) {
    return 'A $count tocchi dall\'anteprima sviluppatore di Playback';
  }

  @override
  String get devPlaybackUnlocked =>
      'Anteprima sviluppatore di Playback sbloccata!';

  @override
  String get craftedWith => 'Creato con ';

  @override
  String get inItaly => ' in Italia';

  @override
  String get switchServerTitle => 'Cambia server';

  @override
  String get switchServerSubtitle =>
      'Seleziona un server attivo o una sorgente di streaming';

  @override
  String get addServerButton => 'Aggiungi server';

  @override
  String get noServersSavedYet => 'Nessun server salvato';

  @override
  String connectedTo(String name) {
    return 'Connesso a $name';
  }

  @override
  String errorConnectingServer(String error) {
    return 'Errore durante la connessione al server: $error';
  }

  @override
  String get renameServerProfile => 'Rinomina profilo server';

  @override
  String get profileNameLabel => 'Nome profilo';

  @override
  String get enterNewNameHint => 'Inserisci nuovo nome';

  @override
  String get removeServerTitle => 'Rimuovi server';

  @override
  String removeServerConfirm(String name) {
    return 'Sei sicuro di voler rimuovere \"$name\" dai server salvati?';
  }

  @override
  String get noPlaylistsFound => 'Nessuna playlist trovata';

  @override
  String get supportDialogDescription =>
      'Musly è un progetto gratuito e open-source. Il tuo supporto aiuta a mantenerlo vivo!';

  @override
  String get supportDialogJoinDiscord => 'Unisciti al nostro Discord';

  @override
  String get supportDialogDiscordSubtitle =>
      'Ottieni aiuto, suggerisci funzionalità, chatta con noi';

  @override
  String get supportDialogDonateTitle => 'Supporta con una donazione';

  @override
  String get supportDialogDonateSubtitle =>
      'Aiuta a coprire i costi dei server e dello sviluppo';

  @override
  String get dontShowAgain => 'Non mostrare più';

  @override
  String get maybeLater => 'Più tardi';

  @override
  String get addAllToQueue => 'Aggiungi tutti alla coda';

  @override
  String songsAddedToQueue(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count brani aggiunti alla coda',
      one: '1 brano aggiunto alla coda',
    );
    return '$_temp0';
  }

  @override
  String get searchInAlbum => 'Cerca nell\'album';

  @override
  String get searchInPlaylist => 'Cerca nella playlist';

  @override
  String get filterTracks => 'Filtra tracce...';

  @override
  String get filterSongs => 'Filtra brani...';

  @override
  String get noSongsInQueue => 'Nessun brano in coda';

  @override
  String get moreOptions => 'Altre opzioni';

  @override
  String get upNext => 'In coda';

  @override
  String get removeSelected => 'Rimuovi selezionati';

  @override
  String get reorderSongs => 'Riordina brani';

  @override
  String get selectSongs => 'Seleziona brani';

  @override
  String get doneReordering => 'Fine riordinamento';

  @override
  String get downloadAlbum => 'Scarica album';

  @override
  String get downloadPlaylist => 'Scarica playlist';

  @override
  String get downloadedTapToRemove => 'Scaricato — tocca per rimuovere';

  @override
  String get downloadingTapToCancel =>
      'Download in corso — tocca per annullare';

  @override
  String get removeDownloadsTitle => 'Rimuovere i download?';

  @override
  String removeAlbumDownloadsConfirm(int count, String name) {
    return 'Rimuovere tutti i $count brani scaricati da \"$name\"?';
  }

  @override
  String removePlaylistDownloadsConfirm(int count, String name) {
    return 'Rimuovere tutti i $count brani scaricati da \"$name\"?';
  }

  @override
  String queuedSongsForDownload(int count) {
    return 'Messi in coda $count brani per il download…';
  }

  @override
  String get songRemovedFromPlaylist => 'Brano rimosso dalla playlist';

  @override
  String errorRemovingSong(String error) {
    return 'Errore durante la rimozione del brano: $error';
  }

  @override
  String errorReorderingSong(String error) {
    return 'Errore durante il riordino del brano: $error';
  }

  @override
  String get removeSongsTitle => 'Rimuovi brani';

  @override
  String removePlaylistSongsConfirm(int count, String name) {
    return 'Rimuovere $count brani da \"$name\"?';
  }

  @override
  String removedSongsFromPlaylist(int count) {
    return 'Rimossi $count brani dalla playlist';
  }

  @override
  String get alreadyInPlaylist => 'Già nella playlist';

  @override
  String alreadyInPlaylistConfirm(String title, String playlist) {
    return '\"$title\" è già presente in \"$playlist\". Vuoi aggiungerlo comunque?';
  }

  @override
  String get addAnyway => 'Aggiungi comunque';

  @override
  String get offlineModeQuestion => 'Modalità offline?';

  @override
  String get drumroll => 'RULLO DI TAMBURI...';

  @override
  String get readyToDiscoverTopSong => 'Pronto a scoprire\nla tua canzone #1?';

  @override
  String get tapToBegin => 'Tocca per iniziare';

  @override
  String get minutesListened => 'MINUTI ASCOLTATI';

  @override
  String get totalHours => 'Ore totali';

  @override
  String get uniqueTracks => 'Brani unici';

  @override
  String get topSongsHeader => 'BRANI PREFERITI';

  @override
  String get yourMostListenedSongs => 'I tuoi brani più ascoltati';

  @override
  String get topArtistsHeader => 'I TUOI ARTISTI TOP';

  @override
  String playsCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count ascolti',
      one: '1 ascolto',
    );
    return '$_temp0';
  }

  @override
  String get topSongBadge => 'Brano #1';

  @override
  String get topArtistMetric => 'Top Artista';

  @override
  String get genreMetric => 'Genere';

  @override
  String get muslyPlaybackHeader => 'MUSLY PLAYBACK';

  @override
  String get enableMuslyConnect => 'Abilita Musly Connect';

  @override
  String get enableMuslyConnectSubtitle =>
      'Rileva i dispositivi vicini tramite Wi-Fi per il controllo remoto e le sessioni di ascolto';

  @override
  String get availableDevices => 'Dispositivi disponibili';

  @override
  String get lanDiscoveryActive =>
      'Rilevamento LAN attivo • Nessun dispositivo nelle vicinanze';

  @override
  String nearbyDevicesFound(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count dispositivi trovati nelle vicinanze',
      one: '1 dispositivo trovato nelle vicinanze',
    );
    return '$_temp0';
  }

  @override
  String get minutes => 'Minuti';

  @override
  String get nowPlayingHeader => 'IN RIPRODUZIONE';

  @override
  String get privacyFirstTitle => 'La tua Privacy al Primo Posto';

  @override
  String get privacyFirstSubtitle => 'I tuoi dati restano sempre con te.';

  @override
  String get noDataSellingTitle => 'Nessuna Vendita di Dati';

  @override
  String get noDataSellingDescription =>
      'Non vendiamo, condividiamo né cediamo mai i tuoi dati personali a terzi.';

  @override
  String get localFirstStorageTitle => 'Salvataggio Locale sul Dispositivo';

  @override
  String get localFirstStorageDescription =>
      'La tua libreria musicale e le credenziali rimangono sul tuo dispositivo.';

  @override
  String get privateOpenTitle => '100% Privata & Aperta';

  @override
  String get privateOpenDescription =>
      'Musly non raccoglie alcuna telemetria. Nessun identificatore, dato di tracciamento o analytics.';

  @override
  String get readFullPrivacyPolicy => 'Leggi la Privacy Policy Completa';

  @override
  String get viewCompleteDetailsWebsite =>
      'Visualizza i dettagli completi sul nostro sito web';

  @override
  String get understandAndContinue => 'Ho capito e continua';

  @override
  String get declineAndExit => 'Rifiuta ed Esci';

  @override
  String get exitApp => 'Esci dall\'App';

  @override
  String get stop => 'Stop';

  @override
  String get closeQueue => 'Chiudi Coda';

  @override
  String get timerOff => 'Disattivo';

  @override
  String get history => 'Cronologia';

  @override
  String get searchInLibrary => 'Cerca nella Libreria';

  @override
  String get add => 'Aggiungi';

  @override
  String get clear => 'Cancella';

  @override
  String get back => 'Indietro';

  @override
  String get previousSlide => 'Precedente';

  @override
  String get nextSlide => 'Successivo';

  @override
  String get radios => 'Radio';

  @override
  String get downloads => 'Download';

  @override
  String get noDownloadedSongsYet => 'Nessun brano scaricato';

  @override
  String get noDownloadedAlbumsYet => 'Nessun album scaricato';

  @override
  String get connectedToWebStream => 'Connesso a Web Stream';

  @override
  String get allowSelfSignedCertificatesSubtitle =>
      'Utile per reti LAN locali o certificati SSL autofirmati';

  @override
  String get legacyAuthenticationSubtitle =>
      'Richiesto per versioni legacy delle API Subsonic';

  @override
  String get certificateFileSubtitle => 'File .crt, .pem o .cer';

  @override
  String get clientIdentityFileSubtitle =>
      'File di identità client .p12 o .pfx';

  @override
  String get copyError => 'Copia errore';

  @override
  String get errorCopiedToClipboard => 'Errore copiato negli appunti';

  @override
  String get failedToUpdateFavorite =>
      'Impossibile aggiornare lo stato preferito';

  @override
  String queuedSongsFromAlbumsForDownload(int songCount, int albumCount) {
    return 'Messi in coda $songCount brani da $albumCount album per il download…';
  }

  @override
  String get downloadAllAlbums => 'Scarica tutti gli album';

  @override
  String get downloadAllFavorites => 'Scarica tutti i preferiti';

  @override
  String get downloadAll => 'Scarica tutto';

  @override
  String get createPlaylistSubtitle =>
      'Crea una playlist personalizzata con i tuoi brani preferiti';

  @override
  String get addMusicSource => 'Aggiungi Sorgente Musicale';

  @override
  String get addMusicSourceSubtitle =>
      'Connetti Navidrome, Jellyfin o Web Stream';

  @override
  String get removeFromFavoritesTitle => 'Rimuovere dai Preferiti?';

  @override
  String removeFromFavoritesConfirm(String title) {
    return 'Vuoi rimuovere \"$title\" dai preferiti?';
  }

  @override
  String failedToRemove(String error) {
    return 'Impossibile rimuovere: $error';
  }

  @override
  String streamUrlLabel(String url) {
    return 'URL Stream: $url';
  }

  @override
  String get shuffleNewSelection => 'Riproduci casualmente nuova selezione';

  @override
  String get sortDurationLongest => 'Durata (Dal più lungo)';

  @override
  String get connectToServer => 'Connettiti al Server';

  @override
  String get renameProfile => 'Rinomina Profilo';

  @override
  String get addWebStream => 'Aggiungi Web Stream';

  @override
  String get addWebStreamSubtitle =>
      'Riproduzione istantanea senza login richiesto';

  @override
  String get recentSearches => 'Ricerche recenti';

  @override
  String get createPlaylistToGetStarted => 'Crea una playlist per iniziare';

  @override
  String get addRadioStationsHint =>
      'Aggiungi stazioni radio nelle impostazioni del tuo server per vederle qui.';

  @override
  String get onboardingNext => 'Avanti';

  @override
  String get onboardingGetStarted => 'Inizia';

  @override
  String get previousSlideTooltip => 'Precedente (Freccia Sinistra)';

  @override
  String get nextSlideTooltip => 'Successivo (Freccia Destra / Spazio)';

  @override
  String get onboardingSlide1TitlePrefix => 'La tua Libreria Musicale,\n';

  @override
  String get onboardingSlide1TitleHighlight => 'Sempre con Te.';

  @override
  String get onboardingSlide1Description =>
      'Connettiti a Navidrome, Subsonic, Jellyfin o riproduci file locali con qualità lossless bit-perfect.';

  @override
  String get onboardingSlide1Feature1Title => 'Libertà Self-Hosted';

  @override
  String get onboardingSlide1Feature1Desc =>
      'Piena compatibilità con le API di Subsonic, Navidrome e Jellyfin.';

  @override
  String get onboardingSlide1Feature2Title => 'Supporto Musica Locale';

  @override
  String get onboardingSlide1Feature2Desc =>
      'Riproduci la tua musica offline direttamente senza configurare un server.';

  @override
  String get onboardingSlide1Feature3Title => 'Audio Hi-Res Lossless';

  @override
  String get onboardingSlide1Feature3Desc =>
      'Riproduzione gapless e bit-perfect per FLAC, ALAC e Opus.';

  @override
  String get onboardingSlide2TitlePrefix => 'Mix Intelligenti,\n';

  @override
  String get onboardingSlide2TitleHighlight => 'Creati su Misura per Te.';

  @override
  String get onboardingSlide2Description =>
      'Musly apprende le tue abitudini sul dispositivo per creare mix quotidiani e riscoprire i tuoi brani preferiti.';

  @override
  String get onboardingSlide2Feature1Title => 'Profilazione Gusti Algoritmica';

  @override
  String get onboardingSlide2Feature1Desc =>
      'Apprende frequenze d\'ascolto, skip e valutazioni in locale.';

  @override
  String get onboardingSlide2Feature2Title => 'Mix Giornalieri Personalizzati';

  @override
  String get onboardingSlide2Feature2Desc =>
      'Playlist automatiche come Per Te, Ascolta di Nuovo e Top Hits.';

  @override
  String get onboardingSlide2Feature3Title =>
      'Elaborazione 100% sul Dispositivo';

  @override
  String get onboardingSlide2Feature3Desc =>
      'Il tuo profilo di ascolto resta rigorosamente sul tuo dispositivo.';

  @override
  String get onboardingSlide3TitlePrefix => 'Completamente Privata.\n';

  @override
  String get onboardingSlide3TitleHighlight =>
      'Zero Pubblicità, Zero Tracciamento.';

  @override
  String get onboardingSlide3Description =>
      'Zero telemetria e zero analytics. Testi sincronizzati, download offline e sincronizzazione in totale privacy.';

  @override
  String get onboardingSlide3Feature1Title => 'Zero Telemetria & Tracciamento';

  @override
  String get onboardingSlide3Feature1Desc =>
      'Nessun SDK di terze parti, niente tracker o pubblicità, 100% open source.';

  @override
  String get onboardingSlide3Feature2Title => 'Testi Sincronizzati nel Tempo';

  @override
  String get onboardingSlide3Feature2Desc =>
      'Testi sincronizzati in tempo reale con supporto a LRCLIB.';

  @override
  String get onboardingSlide3Feature3Title => 'Gestore Download Offline';

  @override
  String get onboardingSlide3Feature3Desc =>
      'Salva intere playlist e album in locale con download multipli.';

  @override
  String get finishTour => 'Termina Tour';

  @override
  String get skip => 'Salta';

  @override
  String get profileNameOptional => 'Nome Profilo (Opzionale)';

  @override
  String get serverUrlRequired => 'URL del Server *';

  @override
  String get lanServerUrlOptional => 'URL Server LAN (Opzionale)';

  @override
  String get usernameRequired => 'Nome Utente *';

  @override
  String get passwordRequired => 'Password *';

  @override
  String get playingInSync => 'In riproduzione sincronizzata';

  @override
  String get switchedBackToThisDevice => 'Tornato su questo dispositivo';

  @override
  String connectedToDeviceName(String device) {
    return 'Connesso a $device';
  }

  @override
  String get whatDoYouWantToPlay => 'Cosa vuoi ascoltare?';

  @override
  String get noLyricsFound => 'Nessun testo disponibile';

  @override
  String get dynamicColor => 'Material You (Colore dinamico)';

  @override
  String get muslyPlayback => 'Musly Playback';

  @override
  String get synthesizingUniverse => 'Sintetizzando il tuo universo sonoro';

  @override
  String get getReadyForBeatDrop => 'Preparati al drop sonoro...';

  @override
  String yourYearInSound(int year) {
    return 'Il tuo $year\nin Musica';
  }

  @override
  String get yourYearInSoundSubtitle =>
      'Hai esplorato profondità sonore, rivissuto momenti e creato ricordi attraverso la musica.';

  @override
  String get yourMusicalChronotype => 'IL TUO CRONOTIPO MUSICALE';

  @override
  String get genreGalaxy => 'GALASSIA DEI GENERI';

  @override
  String get soundsThatGuidedYou => 'I suoni che ti hanno guidato';

  @override
  String get yourMusicalAnchors => 'I tuoi pilastri musicali';

  @override
  String get yourListeningPersonality => 'LA TUA PERSONALITÀ MUSICALE';

  @override
  String get yourYearInReviewIsReady => 'Il tuo Year in Review è pronto!';

  @override
  String get chronotypeMidnightWanderer => 'Esploratore Notturno 🌙';

  @override
  String get chronotypeMidnightWandererDesc =>
      'I tuoi momenti musicali più profondi avvengono a tarda notte, quando il mondo tace.';

  @override
  String get chronotypeSunriseHarmonizer => 'Armonizzatore dell\'Alba ☀️';

  @override
  String get chronotypeSunriseHarmonizerDesc =>
      'Inizi ogni mattina con ritmo, impostando la colonna sonora per l\'intera giornata.';

  @override
  String get chronotypeAfternoonFlow => 'Flusso del Pomeriggio ⚡';

  @override
  String get chronotypeAfternoonFlowDesc =>
      'Il pomeriggio è il tuo momento clou per l\'ascolto, alimentando la tua energia con suoni carichi di ritmo.';

  @override
  String get chronotypeTwilightLounger => 'Sognatore del Crepuscolo 🌆';

  @override
  String get chronotypeTwilightLoungerDesc =>
      'Le serate sono fatte per rilassarsi e perdersi in viaggi immersivi tra gli album.';

  @override
  String get archetypeLuminary => 'Il Luminare';

  @override
  String get archetypeLuminaryBadge => 'ESPLORATORE SONORO';

  @override
  String get archetypeLuminaryDesc =>
      'Porti alla luce generi diversi e cerchi costantemente nuovi orizzonti musicali.';

  @override
  String get archetypeLuminaryTrait1 => 'Gusto Eclettico';

  @override
  String get archetypeLuminaryTrait2 => 'Fluido tra Generi';

  @override
  String get archetypeLuminaryTrait3 => 'Alta Scoperta';

  @override
  String get archetypeDevotee => 'Il Devoto';

  @override
  String get archetypeDevoteeBadge => 'SUPERFAN';

  @override
  String get archetypeDevoteeDesc =>
      'Quando ami un artista o un album, lo ascolti a ripetizione con dedizione senza pari.';

  @override
  String get archetypeDevoteeTrait1 => 'Profonda Fedeltà';

  @override
  String get archetypeDevoteeTrait2 => 'Ascoltatore di Album';

  @override
  String get archetypeDevoteeTrait3 => 'Legame Emotivo';

  @override
  String get archetypeNightOwl => 'Il Gufo Notturno';

  @override
  String get archetypeNightOwlBadge => 'VIBRAZIONI NOTTURNE';

  @override
  String get archetypeNightOwlDesc =>
      'La tua anima appartiene ai paesaggi sonori di mezzanotte, accordi d\'atmosfera e sessioni sotto le stelle.';

  @override
  String get archetypeNightOwlTrait1 => 'Atmosferico';

  @override
  String get archetypeNightOwlTrait2 => 'Introspettivo';

  @override
  String get archetypeNightOwlTrait3 => 'Flusso Notturno';

  @override
  String get archetypeSunrise => 'L\'Armonizzatore dell\'Alba';

  @override
  String get archetypeSunriseBadge => 'CATALIZZATORE D\'ENERGIA';

  @override
  String get archetypeSunriseDesc =>
      'Svegli il mondo con vibrazioni positive e lasci che melodie ottimiste accendano la tua giornata.';

  @override
  String get archetypeSunriseTrait1 => 'Coinvolgente';

  @override
  String get archetypeSunriseTrait2 => 'Energia Mattutina';

  @override
  String get archetypeSunriseTrait3 => 'Carica Ritmica';

  @override
  String get archetypeAlchemist => 'L\'Alchimista Sonoro';

  @override
  String get archetypeAlchemistBadge => 'CURATORE DI VIBRAZIONI';

  @override
  String get archetypeAlchemistDesc =>
      'Trasformi i momenti quotidiani in esperienze cinematografiche con colonne sonore perfettamente curate.';

  @override
  String get archetypeAlchemistTrait1 => 'Istinto da Curatore';

  @override
  String get archetypeAlchemistTrait2 => 'Vibrazione Cinematografica';

  @override
  String get archetypeAlchemistTrait3 => 'Maestro d\'Atmosfera';

  @override
  String get percentileTop05 => 'Top 0.5% Ascoltatore Globale';

  @override
  String get percentileTop1 => 'Top 1% Ascoltatore Globale';

  @override
  String get percentileTop5 => 'Top 5% Ascoltatore Globale';

  @override
  String get percentileTop10 => 'Top 10% Ascoltatore Globale';

  @override
  String get percentileTopAficionado => 'Top Appassionato di Musica';

  @override
  String get superfanBadge01 => 'Top 0.1% Superfan';

  @override
  String get superfanBadge1 => 'Top 1% Fan';

  @override
  String get superfanBadge5 => 'Top 5% Fan';
}
